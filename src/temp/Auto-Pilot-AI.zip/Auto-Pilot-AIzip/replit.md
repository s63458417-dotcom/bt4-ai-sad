# BT4 AI - Browser Automation Agent

## Overview

BT4 AI is a browser automation agent application that allows users to submit natural language prompts and have an AI-driven agent perform web browsing tasks. The system uses Puppeteer for headless browser control, stores API keys for various AI providers, and tracks task execution with detailed logging including screenshots and action records.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight router)
- **State Management**: TanStack React Query for server state with automatic polling for task status updates
- **Styling**: Tailwind CSS with CSS variables for theming, following a dark theme design system
- **UI Components**: shadcn/ui component library (New York style) built on Radix UI primitives
- **Build Tool**: Vite with HMR support

The frontend follows a page-based structure with shared components:
- `client/src/pages/` - Main views (Dashboard, TaskDetails, Settings)
- `client/src/components/` - Reusable components including a custom Sidebar
- `client/src/hooks/` - Custom hooks for API keys, tasks, and mobile detection
- `client/src/components/ui/` - shadcn/ui component library

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful endpoints defined in `shared/routes.ts` with Zod validation
- **Browser Automation**: Puppeteer for headless browser control
- **Build**: esbuild for server bundling, Vite for client

The server architecture includes:
- `server/index.ts` - Express app setup with logging middleware
- `server/routes.ts` - API route handlers for keys, tasks, and logs
- `server/storage.ts` - Database access layer implementing IStorage interface
- `server/services/agent.ts` - AgentService class handling browser automation tasks

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts`
- **Migrations**: Managed via `drizzle-kit push`

Database tables:
- `api_keys` - Stores provider API keys (bt4, huggingface, openai) with activation status
- `tasks` - Tracks automation tasks with prompt, status, and result
- `task_logs` - Stores execution logs including screenshots, actions, and errors

### Shared Code Pattern
The `shared/` directory contains code used by both frontend and backend:
- `shared/schema.ts` - Drizzle table definitions and Zod schemas
- `shared/routes.ts` - API route definitions with type-safe request/response schemas

## External Dependencies

### Third-Party Services
- **AI Providers**: Supports multiple AI providers (bt4, huggingface, openai) via configurable API keys stored in database
- **Browser Automation**: Puppeteer with Chromium for headless browser control

### Database
- **PostgreSQL**: Primary data store, connection via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database queries and schema management

### Key NPM Packages
- `puppeteer` - Headless browser automation
- `drizzle-orm` / `drizzle-zod` - Database ORM and schema validation
- `@tanstack/react-query` - Server state management
- `zod` - Runtime type validation
- `express` - HTTP server framework
- Radix UI primitives - Accessible UI components