# BT4 AI Chat Interface Design Guidelines

## Design Approach
**System:** Hybrid approach combining ChatGPT's conversation clarity with DeepSeek's visual refinement and Linear's precision. Focus on readability, distraction-free interaction, and intelligent information hierarchy.

## Typography
**Font Families:** 
- Interface: Inter (all weights via Google Fonts CDN)
- Code blocks: JetBrains Mono

**Hierarchy:**
- Chat messages: 15px (user), 15px (AI responses)
- Sidebar items: 14px regular, 13px timestamps
- Input placeholder: 15px
- Section headers (7 Days, 30 Days): 12px uppercase, tracking-wide, font-semibold
- Brand "BT4 AI": 18px font-bold

## Layout System
**Spacing Primitives:** Tailwind units of 2, 3, 4, 6, 8, 12, 16
- Component padding: p-3, p-4
- Section gaps: gap-2, gap-4
- Margins: m-2, m-4, m-6

**Grid Structure:**
- Sidebar: 260px fixed width on desktop, hidden on mobile with hamburger toggle
- Main chat area: Flex-1 with max-width of 800px centered
- Message input container: Fixed bottom with backdrop blur

## Component Library

### Sidebar Navigation
**Structure:**
- Top: "BT4 AI" brand with icon (24px), "New Chat" button with plus icon
- Middle: Scrollable chat history with time-based groups, each chat shows truncated title (1 line), timestamp below
- Bottom: User profile section with avatar, username, settings icon

**Chat History Items:**
- Rounded rectangles (rounded-lg)
- Hover state with subtle highlight
- Active chat has distinct visual treatment
- Three-dot menu on hover for actions (rename, delete)

### Main Chat Area
**Message Layout:**
- User messages: Align right, max-width 75%, compact bubble
- AI messages: Full-width blocks with subtle background differentiation
- Avatar indicators: 32px circles, user on right, AI logo on left
- Spacing between messages: space-y-6
- Timestamps: Small, subtle, appear on hover

**Message Features:**
- Code blocks: Syntax highlighting with copy button, rounded corners
- Copy message button on hover
- Regenerate button for AI responses
- Markdown rendering for formatting

### Bottom Input Area
**Fixed Container:**
- Backdrop blur effect (backdrop-blur-xl)
- Inner max-width: 800px centered
- Padding from edges: px-4, py-4

**Input Component:**
- Multi-line textarea with auto-expand (max 6 lines)
- Rounded-2xl border
- Toggle pills (DeepThink/Search) positioned top-right of input, each 80px wide, rounded-full
- Send button: 40px circle, positioned bottom-right, icon-only
- Attachment button: Icon button, bottom-left
- Character count when approaching limit

### Additional UI Elements
**Top Bar (Mobile):**
- Hamburger menu (left), current chat title (center), options menu (right)
- Height: h-16

**Empty State:**
- Centered content with "BT4 AI" logo (64px)
- Suggested prompts: 4 cards in 2x2 grid, rounded-xl, minimal hover lift
- Welcome message: "How can BT4 AI help you today?"

**Loading States:**
- Thinking indicator: Animated dots pattern
- Streaming text: Cursor blink effect at end

## Icons
**Library:** Heroicons (via CDN)
**Usage:**
- Menu/Navigation: 20px
- Actions (copy, regenerate): 16px  
- Send button: 20px
- Toggles: 16px inline with text

## Animations
**Minimal Motion:**
- Message appearance: Subtle fade-in (200ms)
- Sidebar toggle: Slide transform (300ms)
- Button interactions: No animations beyond standard hover states
- Streaming text: Smooth append, no character-by-character animation

## Images
**No hero images required.** This is a functional chat interface.

**Brand Assets:**
- BT4 AI logo: Simple geometric icon, 24px sidebar, 64px empty state
- User avatars: 32px circles throughout

## Responsive Behavior
**Desktop (1024px+):** Sidebar always visible, full layout
**Tablet (768px-1023px):** Collapsible sidebar, overlay mode
**Mobile (<768px):** Hidden sidebar with hamburger, full-width chat, sticky input