import { useApiKeys, useCreateApiKey, useDeleteApiKey, useToggleApiKey } from "@/hooks/use-api-keys";
import { useState } from "react";
import { Trash2, Key, Loader2, Plus, AlertCircle, Eye, EyeOff, Bot } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

export default function Settings() {
  const { data: keys, isLoading } = useApiKeys();
  const { mutate: deleteKey } = useDeleteApiKey();
  const { mutate: toggleKey } = useToggleApiKey();
  const { toast } = useToast();

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this key?")) {
      deleteKey(id, {
        onSuccess: () => toast({ title: "Key deleted" }),
        onError: () => toast({ title: "Failed to delete key", variant: "destructive" }),
      });
    }
  };

  const handleToggle = (id: number, currentStatus: boolean | null) => {
    toggleKey(
      { id, isActive: !currentStatus },
      {
        onSuccess: () => toast({ title: currentStatus ? "Key deactivated" : "Key activated" }),
      }
    );
  };

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Settings</h1>
          <p className="text-muted-foreground">Manage your API keys and model configurations.</p>
        </div>
        <AddKeyDialog />
      </div>

      <div className="bg-card border border-white/10 rounded-xl overflow-hidden shadow-sm">
        <div className="p-6 border-b border-white/5 flex items-center gap-2">
          <Key className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-semibold">API Keys</h2>
        </div>
        
        {isLoading ? (
          <div className="p-12 flex justify-center">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
        ) : keys?.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-muted-foreground mb-4">No API keys configured</p>
            <AddKeyDialog />
          </div>
        ) : (
          <div className="divide-y divide-white/5">
            {keys?.map((key) => (
              <div key={key.id} className="p-6 flex items-center justify-between hover:bg-white/5 transition-colors group">
                <div className="space-y-1">
                  <div className="flex items-center gap-3">
                    <span className="font-medium text-white">{key.label || key.provider}</span>
                    <span className={cn(
                      "text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full border",
                      key.provider === "openai" ? "bg-green-500/10 text-green-400 border-green-500/20" :
                      key.provider === "deepseek" ? "bg-blue-500/10 text-blue-400 border-blue-500/20" :
                      "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                    )}>
                      {key.provider}
                    </span>
                    {key.model && (
                      <span className="text-xs text-muted-foreground border border-white/10 px-2 py-0.5 rounded-md font-mono bg-white/5">
                        {key.model}
                      </span>
                    )}
                  </div>
                  <div className="text-sm font-mono text-muted-foreground flex items-center gap-2">
                    <span className="opacity-50">••••••••••••••••</span>
                    {key.key.slice(-4)}
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <span className={cn("text-xs font-medium", key.isActive ? "text-emerald-400" : "text-muted-foreground")}>
                      {key.isActive ? "Active" : "Inactive"}
                    </span>
                    <Switch 
                      checked={!!key.isActive} 
                      onCheckedChange={() => handleToggle(key.id, key.isActive)} 
                    />
                  </div>
                  <button 
                    onClick={() => handleDelete(key.id)}
                    className="p-2 text-muted-foreground hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"
                    title="Delete Key"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-blue-900/20 to-indigo-900/20 border border-blue-500/10 rounded-xl p-6">
          <div className="flex items-start gap-4">
             <div className="bg-blue-500/20 p-3 rounded-lg">
                <Bot className="w-6 h-6 text-blue-400" />
             </div>
             <div>
               <h3 className="font-semibold text-white mb-1">Key Rotation</h3>
               <p className="text-sm text-muted-foreground">
                 The system automatically rotates between active keys for the same provider to distribute load and avoid rate limits.
               </p>
             </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-orange-900/20 to-red-900/20 border border-orange-500/10 rounded-xl p-6">
          <div className="flex items-start gap-4">
             <div className="bg-orange-500/20 p-3 rounded-lg">
                <AlertCircle className="w-6 h-6 text-orange-400" />
             </div>
             <div>
               <h3 className="font-semibold text-white mb-1">Security Note</h3>
               <p className="text-sm text-muted-foreground">
                 Keys are stored securely. Never share your API keys or commit them to public repositories.
               </p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function AddKeyDialog() {
  const [open, setOpen] = useState(false);
  const [showSecret, setShowSecret] = useState(false);
  const { mutate, isPending } = useCreateApiKey();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    provider: "openai",
    key: "",
    baseUrl: "",
    model: "",
    label: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutate(formData, {
      onSuccess: () => {
        setOpen(false);
        setFormData({ provider: "openai", key: "", baseUrl: "", model: "", label: "" });
        toast({ title: "API Key added successfully" });
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="flex items-center gap-2 px-4 py-2 bg-primary hover:bg-primary/90 text-white rounded-lg font-medium transition-all shadow-lg shadow-primary/20 text-sm">
          <Plus className="w-4 h-4" />
          <span>Add API Key</span>
        </button>
      </DialogTrigger>
      <DialogContent className="bg-[#171717] border-white/10 sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">Add New API Key</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 mt-4 pb-4">
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Provider</label>
                <select 
                  value={formData.provider}
                  onChange={(e) => setFormData({...formData, provider: e.target.value})}
                  className="w-full bg-black/40 border border-white/5 rounded-xl p-3 text-sm focus:border-primary/50 outline-none appearance-none text-white"
                >
                  <option value="openai">OpenAI</option>
                  <option value="deepseek">DeepSeek</option>
                  <option value="huggingface">Hugging Face</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Label (Optional)</label>
                <input
                  type="text"
                  value={formData.label}
                  onChange={(e) => setFormData({...formData, label: e.target.value})}
                  placeholder="My Personal Key"
                  className="w-full bg-black/40 border border-white/5 rounded-xl p-3 text-sm focus:border-primary/50 outline-none text-white placeholder:text-white/20"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">API Secret Key</label>
              <div className="relative">
                <input
                  type={showSecret ? "text" : "password"}
                  value={formData.key}
                  onChange={(e) => setFormData({...formData, key: e.target.value})}
                  required
                  placeholder="sk-..."
                  className="w-full bg-black/40 border border-white/5 rounded-xl p-3 text-sm focus:border-primary/50 outline-none pr-12 text-white placeholder:text-white/20"
                />
                <button
                  type="button"
                  onClick={() => setShowSecret(!showSecret)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-white transition-colors"
                >
                  {showSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Base URL (Optional)</label>
                <input
                  type="text"
                  value={formData.baseUrl}
                  onChange={(e) => setFormData({...formData, baseUrl: e.target.value})}
                  placeholder="https://api..."
                  className="w-full bg-black/40 border border-white/5 rounded-xl p-3 text-sm focus:border-primary/50 outline-none text-white placeholder:text-white/20"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Model ID (Optional)</label>
                <input
                  type="text"
                  value={formData.model}
                  onChange={(e) => setFormData({...formData, model: e.target.value})}
                  placeholder="gpt-4o"
                  className="w-full bg-black/40 border border-white/5 rounded-xl p-3 text-sm focus:border-primary/50 outline-none text-white placeholder:text-white/20"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={isPending}
              className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold disabled:opacity-50 transition-all w-full shadow-lg shadow-blue-600/20 uppercase tracking-widest text-xs"
            >
              {isPending ? (
                <div className="flex items-center justify-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Saving...</span>
                </div>
              ) : (
                "Save API Key"
              )}
            </button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
