import { useParams, Link, useLocation } from "wouter";
import { useTask, useTaskLogs, useCreateTask } from "@/hooks/use-tasks";
import { 
  ArrowLeft, Loader2, Terminal, Monitor, AlertCircle, 
  CheckCircle2, ChevronDown, ChevronUp, Send, Globe, 
  Plus, ChevronUp as ChevronUpIcon 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export default function TaskDetails() {
  const { id } = useParams<{ id: string }>();
  const taskId = parseInt(id || "0");
  const [, setLocation] = useLocation();
  const { data: task, isLoading: isTaskLoading } = useTask(taskId);
  const { data: logs, isLoading: isLogsLoading } = useTaskLogs(taskId);
  const { mutate: createTask, isPending: isCreating } = useCreateTask();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isLogsOpen, setIsLogsOpen] = useState(true);
  const [prompt, setPrompt] = useState("");
  const [deepThink, setDeepThink] = useState(false);
  const [searchEnabled, setSearchEnabled] = useState(false);

  // Auto-scroll logs
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!prompt.trim() || isCreating) return;

    createTask(
      { prompt },
      {
        onSuccess: (newTask) => {
          setPrompt("");
          // Use location to navigate within the router
          setLocation(`/tasks/${newTask.id}`);
        },
      }
    );
  };

  if (isTaskLoading && !task) {
    return (
      <div className="flex items-center justify-center h-full min-h-[500px]">
        <Loader2 className="w-10 h-10 text-primary animate-spin" />
      </div>
    );
  }

  if (!task) return <div className="p-8">Task not found</div>;

  return (
    <div className="flex flex-col h-full bg-[#0d0d0d]">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8 max-w-4xl mx-auto w-full scroll-smooth" ref={scrollRef}>
        {/* User Prompt Message */}
        <div className="flex justify-end animate-in fade-in slide-in-from-right-4 duration-500">
          <div className="bg-[#2f2f2f] text-white p-4 rounded-2xl max-w-[80%] shadow-lg">
            <p className="text-base whitespace-pre-wrap">{task.prompt}</p>
          </div>
        </div>

        {/* AI Response / Logs */}
        <div className="flex gap-4 animate-in fade-in slide-in-from-left-4 duration-500">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center shrink-0 mt-1 shadow-lg shadow-blue-600/20">
            <span className="text-white font-bold text-xs">BT4</span>
          </div>
          <div className="flex-1 space-y-6">
            <div className="space-y-4">
              {/* Collapsible Progress Dropdown */}
              <div className="bg-[#171717] rounded-2xl border border-white/5 overflow-hidden shadow-lg transition-all duration-300">
                <Collapsible open={isLogsOpen} onOpenChange={setIsLogsOpen} className="w-full">
                  <CollapsibleTrigger asChild>
                    <Button 
                      variant="ghost" 
                      className="w-full flex items-center justify-between gap-2 px-6 py-4 h-auto hover:bg-white/5 transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center transition-transform group-active:scale-95",
                          task.status === 'running' ? "bg-blue-500/10 text-blue-500" :
                          task.status === 'completed' ? "bg-emerald-500/10 text-emerald-500" :
                          "bg-red-500/10 text-red-500"
                        )}>
                          {task.status === 'running' ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : task.status === 'completed' ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : (
                            <AlertCircle className="w-4 h-4" />
                          )}
                        </div>
                        <div className="flex flex-col items-start">
                          <span className="text-sm font-bold text-white tracking-tight uppercase">
                            {task.status === 'running' ? "Processing Task" : 
                             task.status === 'completed' ? "Task Completed" : 
                             "Task Failed"}
                          </span>
                          <span className="text-[10px] text-muted-foreground font-mono uppercase tracking-widest">
                            {logs?.length || 0} Steps Executed
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-tighter opacity-0 group-hover:opacity-100 transition-opacity">Details</span>
                        {isLogsOpen ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                      </div>
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="px-6 pb-6 pt-2 space-y-4 border-t border-white/5 bg-black/20">
                    <div className="space-y-4 mt-2">
                      {logs?.map((log) => (
                        <div key={log.id} className="animate-in fade-in slide-in-from-top-2 duration-300">
                          {log.type === 'error' && (
                            <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-red-400 flex items-start gap-3">
                              <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                              <span className="text-sm font-medium">{log.content}</span>
                            </div>
                          )}
                          
                          {log.type === 'info' && (
                            <div className="flex gap-3">
                              <div className="w-1.5 h-1.5 rounded-full bg-white/10 mt-2 shrink-0" />
                              <p className="text-muted-foreground text-sm leading-relaxed">{log.content}</p>
                            </div>
                          )}
                          
                          {log.type === 'action' && (
                            <div className="flex items-center gap-3 text-blue-400 text-sm font-bold py-1 bg-blue-400/5 rounded-lg px-3 border border-blue-400/10">
                              <Terminal className="w-4 h-4" />
                              <span className="tracking-tight">{log.content}</span>
                            </div>
                          )}

                          {log.type === 'screenshot' && (
                            <div className="mt-4 rounded-2xl overflow-hidden border border-white/10 bg-black shadow-2xl group max-w-lg mx-auto">
                              <img 
                                src={log.content} 
                                alt="Task screenshot" 
                                className="w-full h-auto max-h-[400px] object-contain transition-transform duration-500 group-hover:scale-[1.05]" 
                              />
                              <div className="bg-white/5 px-4 py-2 flex items-center justify-between border-t border-white/5">
                                <div className="flex items-center gap-2">
                                  <Monitor className="w-3 h-3 text-muted-foreground" />
                                  <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">Viewport Capture</span>
                                </div>
                                <span className="text-[10px] text-muted-foreground/40 font-mono">1280x800</span>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              </div>

              {task.status === 'completed' && task.result && (
                <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-6 shadow-lg animate-in zoom-in-95 duration-500">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-emerald-400">Final Result</h3>
                  </div>
                  <p className="text-foreground leading-relaxed">{task.result}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-6 p-4 border-t border-white/5 text-[10px] text-muted-foreground uppercase tracking-widest font-bold bg-[#0d0d0d]">
        <div className="flex items-center gap-2">
          <span>Task ID</span>
          <span className="text-white">#{task.id}</span>
        </div>
        <div className="flex items-center gap-2">
          <span>Created</span>
          <span className="text-white">{new Date(task.createdAt || "").toLocaleString()}</span>
        </div>
        <div className="flex items-center gap-2">
          <span>Status</span>
          <span className={cn(
            task.status === 'completed' ? "text-emerald-400" :
            task.status === 'running' ? "text-blue-400" : "text-red-400"
          )}>{task.status}</span>
        </div>
      </div>

      {/* Chat Input Area */}
      <div className="p-4 md:p-8 w-full max-w-4xl mx-auto">
        <div className="relative group">
          <div className="bg-[#171717] rounded-3xl border border-white/5 p-4 shadow-2xl focus-within:border-white/10 transition-colors">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit();
                }
              }}
              placeholder="Message BT4 AI"
              className="w-full bg-transparent border-none outline-none text-white text-lg placeholder:text-muted-foreground/40 resize-none min-h-[44px] max-h-48 py-2 px-1"
              rows={1}
            />
            
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setDeepThink(!deepThink)}
                  className={cn(
                    "rounded-full h-8 px-4 flex items-center gap-2 transition-all",
                    deepThink ? "bg-white/10 text-white" : "text-muted-foreground hover:bg-white/5"
                  )}
                >
                  <div className={cn("w-4 h-4 rounded-full border-2 flex items-center justify-center transition-colors", deepThink ? "border-white bg-white/20" : "border-muted-foreground/50")}>
                    {deepThink && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </div>
                  <span className="text-xs font-semibold">DeepThink</span>
                </Button>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSearchEnabled(!searchEnabled)}
                  className={cn(
                    "rounded-full h-8 px-4 flex items-center gap-2 transition-all",
                    searchEnabled ? "bg-white/10 text-white" : "text-muted-foreground hover:bg-white/5"
                  )}
                >
                  <Globe className="w-4 h-4" />
                  <span className="text-xs font-semibold">Search</span>
                </Button>
              </div>

              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-white rounded-full">
                  <Plus className="w-5 h-5" />
                </Button>
                <Button 
                  onClick={() => handleSubmit()}
                  disabled={!prompt.trim() || isCreating}
                  className={cn(
                    "h-9 w-9 rounded-full transition-all",
                    prompt.trim() ? "bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-600/20" : "bg-white/5 text-muted-foreground"
                  )}
                >
                  {isCreating ? <Loader2 className="w-5 h-5 animate-spin" /> : <ChevronUpIcon className="w-6 h-6" />}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
