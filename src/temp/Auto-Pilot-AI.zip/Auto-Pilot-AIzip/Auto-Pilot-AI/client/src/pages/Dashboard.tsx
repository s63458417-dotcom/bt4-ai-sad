import { useState } from "react";
import { useCreateTask } from "@/hooks/use-tasks";
import { Search, Globe, ChevronUp, Send, Loader2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";

export default function Dashboard() {
  const [prompt, setPrompt] = useState("");
  const [deepThink, setDeepThink] = useState(false);
  const [searchEnabled, setSearchEnabled] = useState(false);
  const { mutate, isPending } = useCreateTask();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!prompt.trim() || isPending) return;

    mutate(
      { prompt },
      {
        onSuccess: (task) => {
          setPrompt("");
          setLocation(`/tasks/${task.id}`);
        },
        onError: (err) => {
          toast({ title: "Error", description: err.message, variant: "destructive" });
        },
      }
    );
  };

  return (
    <div className="flex flex-col h-full bg-[#0d0d0d]">
      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <div className="flex flex-col items-center max-w-2xl w-full space-y-8 animate-in fade-in duration-700">
          <div className="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center shadow-2xl shadow-blue-600/20">
            <span className="text-white font-bold text-2xl">BT4</span>
          </div>
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-bold text-white tracking-tight">Hi, I'm BT4 AI.</h1>
            <p className="text-lg text-muted-foreground/80">How can I help you today?</p>
          </div>
        </div>
      </div>

      <div className="p-4 md:p-8 w-full max-w-4xl mx-auto">
        <div className="relative group">
          <div className="bg-[#171717] rounded-3xl border border-white/5 p-4 shadow-2xl focus-within:border-white/10 transition-colors">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit();
                }
              }}
              placeholder="Message BT4 AI"
              className="w-full bg-transparent border-none outline-none text-white text-lg placeholder:text-muted-foreground/40 resize-none min-h-[44px] max-h-48 py-2 px-1"
              rows={1}
            />
            
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setDeepThink(!deepThink)}
                  className={cn(
                    "rounded-full h-8 px-4 flex items-center gap-2 transition-all",
                    deepThink ? "bg-white/10 text-white" : "text-muted-foreground hover:bg-white/5"
                  )}
                >
                  <div className={cn("w-4 h-4 rounded-full border-2 flex items-center justify-center transition-colors", deepThink ? "border-white bg-white/20" : "border-muted-foreground/50")}>
                    {deepThink && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </div>
                  <span className="text-xs font-semibold">DeepThink</span>
                </Button>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSearchEnabled(!searchEnabled)}
                  className={cn(
                    "rounded-full h-8 px-4 flex items-center gap-2 transition-all",
                    searchEnabled ? "bg-white/10 text-white" : "text-muted-foreground hover:bg-white/5"
                  )}
                >
                  <Globe className="w-4 h-4" />
                  <span className="text-xs font-semibold">Search</span>
                </Button>
              </div>

              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-white rounded-full">
                  <Plus className="w-5 h-5" />
                </Button>
                <Button 
                  onClick={() => handleSubmit()}
                  disabled={!prompt.trim() || isPending}
                  className={cn(
                    "h-9 w-9 rounded-full transition-all",
                    prompt.trim() ? "bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-600/20" : "bg-white/5 text-muted-foreground"
                  )}
                >
                  {isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <ChevronUp className="w-6 h-6" />}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
