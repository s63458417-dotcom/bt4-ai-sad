import { Link, useLocation } from "wouter";
import { Settings, Plus, MessageSquare, MoreHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTasks } from "@/hooks/use-tasks";
import { format, isAfter, subDays } from "date-fns";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

export function Sidebar() {
  const [location] = useLocation();
  const { data: tasks } = useTasks();

  const now = new Date();
  const sevenDaysAgo = subDays(now, 7);
  const thirtyDaysAgo = subDays(now, 30);

  const last7Days = tasks?.filter(t => isAfter(new Date(t.createdAt || 0), sevenDaysAgo)) || [];
  const last30Days = tasks?.filter(t => {
    const date = new Date(t.createdAt || 0);
    return isAfter(date, thirtyDaysAgo) && !isAfter(date, sevenDaysAgo);
  }) || [];

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-[#171717] border-r border-white/5 flex flex-col z-50">
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
            <span className="text-white font-bold text-sm">BT4</span>
          </div>
          <h1 className="font-bold text-lg tracking-tight text-white">BT4 AI</h1>
        </div>
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-white">
            <Plus className="w-4 h-4" />
          </Button>
        </Link>
      </div>

      <div className="flex-1 overflow-y-auto px-3 space-y-6 py-2">
        {last7Days.length > 0 && (
          <div className="space-y-1">
            <h2 className="px-3 text-[11px] font-semibold text-muted-foreground/50 uppercase tracking-wider">7 Days</h2>
            {last7Days.map((task) => (
              <ChatItem key={task.id} id={task.id} label={task.prompt} active={location === `/tasks/${task.id}`} />
            ))}
          </div>
        )}

        {last30Days.length > 0 && (
          <div className="space-y-1">
            <h2 className="px-3 text-[11px] font-semibold text-muted-foreground/50 uppercase tracking-wider">30 Days</h2>
            {last30Days.map((task) => (
              <ChatItem key={task.id} id={task.id} label={task.prompt} active={location === `/tasks/${task.id}`} />
            ))}
          </div>
        )}
      </div>

      <div className="p-4 border-t border-white/5 space-y-2">
        <Link href="/settings">
          <div className={cn(
            "flex items-center gap-3 px-3 py-2 rounded-lg transition-colors cursor-pointer group",
            location === "/settings" ? "bg-white/10 text-white" : "text-muted-foreground hover:bg-white/5 hover:text-white"
          )}>
            <Settings className="w-4 h-4" />
            <span className="text-sm font-medium">Settings</span>
          </div>
        </Link>
        <div className="flex items-center justify-between px-3 py-2">
          <div className="flex items-center gap-3">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="bg-purple-600 text-white text-xs">B</AvatarFallback>
            </Avatar>
            <span className="text-sm font-medium text-white truncate max-w-[120px]">Baatin Arolu</span>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
            <MoreHorizontal className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </aside>
  );
}

function ChatItem({ id, label, active }: { id: number, label: string, active: boolean }) {
  return (
    <Link href={`/tasks/${id}`}>
      <div className={cn(
        "group flex items-center gap-3 px-3 py-2 rounded-lg transition-colors cursor-pointer text-sm",
        active ? "bg-white/10 text-white" : "text-muted-foreground hover:bg-white/5 hover:text-white"
      )}>
        <MessageSquare className="w-4 h-4 shrink-0" />
        <span className="truncate flex-1">{label}</span>
      </div>
    </Link>
  );
}
