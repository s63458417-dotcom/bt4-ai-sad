import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertTask, type Task, type TaskLog } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export function useTasks() {
  return useQuery<Task[]>({
    queryKey: [api.tasks.list.path],
    queryFn: async () => {
      const res = await fetch(api.tasks.list.path);
      if (!res.ok) throw new Error("Failed to fetch tasks");
      return api.tasks.list.responses[200].parse(await res.json());
    },
    refetchInterval: 5000, // Poll for status updates
  });
}

export function useTask(id: number) {
  return useQuery<Task>({
    queryKey: [api.tasks.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.tasks.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) throw new Error("Task not found");
      if (!res.ok) throw new Error("Failed to fetch task");
      return api.tasks.get.responses[200].parse(await res.json());
    },
    refetchInterval: (query) => {
      const data = query.state.data;
      // Stop polling if completed or failed
      if (data && (data.status === "completed" || data.status === "failed")) {
        return false;
      }
      return 2000;
    },
  });
}

export function useTaskLogs(id: number) {
  return useQuery<TaskLog[]>({
    queryKey: [api.tasks.getLogs.path, id],
    queryFn: async () => {
      const url = buildUrl(api.tasks.getLogs.path, { id });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch logs");
      return api.tasks.getLogs.responses[200].parse(await res.json());
    },
    refetchInterval: (query) => {
      // We need to access the task status to know if we should stop polling logs,
      // but strictly for the logs query, we'll just poll frequently while the component is mounted
      // Ideally we'd link this to the parent task status.
      return 2000;
    },
  });
}

export function useCreateTask() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertTask) => {
      const res = await apiRequest("POST", api.tasks.create.path, data);
      return api.tasks.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.tasks.list.path] });
    },
  });
}
