## Packages
date-fns | Date formatting for logs and tasks
framer-motion | Smooth transitions and list animations

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  mono: ["JetBrains Mono", "monospace"],
}
