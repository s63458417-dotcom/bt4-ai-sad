
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { AgentService } from "./services/agent";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Initialize Agent Service
  const agentService = new AgentService(storage);

  // API Keys Routes
  app.get(api.keys.list.path, async (req, res) => {
    const keys = await storage.getApiKeys();
    res.json(keys);
  });

  app.post(api.keys.create.path, async (req, res) => {
    try {
      const input = api.keys.create.input.parse(req.body);
      const key = await storage.createApiKey(input);
      res.status(201).json(key);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.keys.delete.path, async (req, res) => {
    await storage.deleteApiKey(Number(req.params.id));
    res.status(204).send();
  });

  app.patch(api.keys.toggle.path, async (req, res) => {
    const { isActive } = req.body;
    const key = await storage.updateApiKey(Number(req.params.id), { isActive });
    res.json(key);
  });

  // Tasks Routes
  app.get(api.tasks.list.path, async (req, res) => {
    const tasks = await storage.getTasks();
    res.json(tasks);
  });

  app.post(api.tasks.create.path, async (req, res) => {
    try {
      const input = api.tasks.create.input.parse(req.body);
      const task = await storage.createTask(input);
      
      // Start the task asynchronously
      agentService.runTask(task.id, task.prompt).catch(console.error);
      
      res.status(201).json(task);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.tasks.get.path, async (req, res) => {
    const task = await storage.getTask(Number(req.params.id));
    if (!task) return res.status(404).json({ message: "Task not found" });
    res.json(task);
  });

  app.get(api.tasks.getLogs.path, async (req, res) => {
    const logs = await storage.getTaskLogs(Number(req.params.id));
    res.json(logs);
  });

  app.post("/api/tasks/:id/answer", async (req, res) => {
    const { answer } = req.body;
    const taskId = Number(req.params.id);
    const task = await storage.getTask(taskId);
    if (!task) return res.status(404).json({ message: "Task not found" });

    await storage.answerQuestion(taskId, answer);
    // Resume task
    agentService.runTask(taskId, `${task.prompt}\nUser provided: ${answer}`).catch(console.error);
    res.json({ message: "Question answered" });
  });

  return httpServer;
}
