
import { IStorage } from "../storage";
import puppeteer from "puppeteer-extra";
import StealthPlugin from "puppeteer-extra-plugin-stealth";

// Use stealth plugin to bypass detection
puppeteer.use(StealthPlugin());

export class AgentService {
  private storage: IStorage;

  constructor(storage: IStorage) {
    this.storage = storage;
  }

  async runTask(taskId: number, prompt: string) {
    await this.storage.updateTaskStatus(taskId, "running");
    await this.storage.addTaskLog({
      taskId,
      type: "info",
      content: `Starting task: ${prompt}`
    });

    let browser;
    try {
      // Launch browser
      await this.storage.addTaskLog({ taskId, type: "info", content: "Launching browser..." });
      
      browser = await puppeteer.launch({
        headless: true,
        protocolTimeout: 60000,
        args: [
          '--no-sandbox', 
          '--disable-setuid-sandbox', 
          '--disable-dev-shm-usage', 
          '--disable-gpu',
          '--single-process'
        ]
      });
      
      const page = await browser.newPage();
      await page.setViewport({ width: 1280, height: 800 });

      // TODO: Implement actual LLM-driven navigation
      // For MVP, we will do a simple navigation if the prompt contains a URL, or just a Google search.
      
      // Smarter extraction: URL, Search, Navigation, or Force Action
      let url: string | null = null;
      let actionNeeded = false;
      const urlMatch = prompt.match(/https?:\/\/[^\s]+/);
      const domainMatch = prompt.match(/(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]/i);

      // Force action for tasks that look like automation
      if (prompt.toLowerCase().match(/create|sign up|register|login|log in|buy|order|submit|click|complete|fill|type|navigate/)) {
        actionNeeded = true;
      }

      if (urlMatch) {
        url = urlMatch[0];
      } else if (domainMatch && (prompt.toLowerCase().includes("go to") || prompt.toLowerCase().includes("visit") || prompt.toLowerCase().includes("open") || prompt.toLowerCase().includes("replit.com") || actionNeeded)) {
        const domain = domainMatch[0];
        url = domain.startsWith('http') ? domain : `https://${domain}`;
      } else if (prompt.toLowerCase().includes("search") || prompt.toLowerCase().includes("find") || prompt.toLowerCase().includes("who is")) {
        url = `https://www.google.com/search?q=${encodeURIComponent(prompt)}`;
      }

      if (!url || actionNeeded) {
        // AI Decision based on prompt for more complex tasks
        const keys = await this.storage.getActiveApiKeys();
        if (keys.length > 0) {
          const keyToUse = keys[0];
          try {
            const response = await fetch(keyToUse.baseUrl || 'https://api.openai.com/v1/chat/completions', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${keyToUse.key}` },
              body: JSON.stringify({
                model: keyToUse.model || 'gpt-4o',
                messages: [
                  { role: 'system', content: 'You are a browser automation expert. Analyze the prompt and provide the target URL and whether an action is required. If the prompt is missing information to proceed, provide a question to the user. Return ONLY a JSON object: {"url": "...", "type": "navigation" | "search" | "action", "actionDescription": "...", "question": "your_question_here"}' },
                  { role: 'user', content: prompt }
                ]
              })
            });
            const data = await response.json();
            let aiDecision;
            try {
              const content = data.choices[0].message.content;
              const jsonMatch = content.match(/\{[\s\S]*\}/);
              aiDecision = JSON.parse(jsonMatch ? jsonMatch[0] : content);
            } catch (parseError) {
              console.error("AI Decision Parse Error:", parseError);
              aiDecision = { type: 'navigation' };
            }

            if (aiDecision.question) {
               await this.storage.addTaskLog({ taskId, type: "info", content: `AI is asking: ${aiDecision.question}` });
               await this.storage.updateTaskStatus(taskId, "paused", undefined, aiDecision.question);
               return; // Pause execution and wait for answer
            }

            if (aiDecision.url) {
              url = aiDecision.url;
              if (url && !url.startsWith('http')) url = `https://${url}`;
            }
            if (aiDecision.type === 'action' || aiDecision.actionDescription) {
              actionNeeded = true;
            }
          } catch (e) {
            if (!url) url = `https://www.google.com/search?q=${encodeURIComponent(prompt)}`;
          }
        }
      }

      if (url) {
        await this.storage.addTaskLog({ taskId, type: "info", content: `BT4 AI is researching: ${prompt}` });
        
        // Use a more human-like user agent
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36');
        
        try {
          await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
        } catch (gotoError) {
          await this.storage.addTaskLog({ taskId, type: "warning", content: "Navigation timed out or failed. Attempting to proceed with current state." });
        }
        
        // CAPTCHA Detection & Smarter Handling
        const captchaData = await page.evaluate(() => {
          const text = document.body.innerText.toLowerCase();
          const selectors = [
            'iframe[src*="captcha"]', 
            'div.g-recaptcha', 
            '#captcha', 
            '.captcha',
            'iframe[title*="reCAPTCHA"]',
            '#cf-turnstile-wrapper'
          ];
          const hasVisibleCaptcha = selectors.some(s => !!document.querySelector(s));
          const isBlocked = text.includes("blocked") || text.includes("access denied") || text.includes("forbidden");
          const isCaptcha = text.includes("captcha") || text.includes("verify you are a human") || text.includes("robot") || hasVisibleCaptcha;
          
          return { isCaptcha, isBlocked };
        });

        if (captchaData.isCaptcha || captchaData.isBlocked) {
          const reason = captchaData.isBlocked ? "Access blocked by the website." : "CAPTCHA detected.";
          await this.storage.addTaskLog({ 
            taskId, 
            type: "warning", 
            content: `BT4 AI encountered an obstacle: ${reason} Moving to alternative approach...` 
          });
          
          // Heuristic: If blocked on Google search, try a different search engine or direct summary
          if (url.includes("google.com/search")) {
             await this.storage.addTaskLog({ taskId, type: "info", content: "Retrying search on DuckDuckGo..." });
             const fallbackUrl = `https://duckduckgo.com/?q=${encodeURIComponent(prompt)}`;
             await page.goto(fallbackUrl, { waitUntil: 'networkidle2' });
          }
        }

        // If an action is needed, attempt to find and interact with elements
        if (actionNeeded) {
          await this.storage.addTaskLog({ taskId, type: "info", content: "Executing requested actions..." });
          
          let actionCount = 0;
          const maxActions = 100; // Force 100 steps
          let lastAction = "";

          while (actionCount < maxActions) {
            actionCount++;
            console.log(`Executing step ${actionCount} of ${maxActions} for task ${taskId}`);
            
            // Wait for stability
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Re-take screenshot for each step
            const stepScreenshot = await page.screenshot({ encoding: "base64" });
            await this.storage.addTaskLog({
              taskId,
              type: "screenshot",
              content: `data:image/png;base64,${stepScreenshot}`,
              metadata: { url: page.url(), step: actionCount }
            });

            const interactiveElements = await page.evaluate(() => {
              const elements = Array.from(document.querySelectorAll('a, button, input, select, textarea, [role="button"], [onclick]'));
              return elements.map((el, index) => {
                const rect = el.getBoundingClientRect();
                const style = window.getComputedStyle(el);
                return {
                  index,
                  tagName: el.tagName,
                  type: (el as HTMLInputElement).type,
                  text: (el as HTMLElement).innerText?.trim() || (el as HTMLInputElement).value || (el as HTMLInputElement).placeholder || el.getAttribute('aria-label') || '',
                  id: el.id,
                  className: el.className,
                  visible: rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden'
                };
              }).filter(el => el.visible && (el.text.length > 0 || el.tagName === 'INPUT' || el.tagName === 'SELECT'));
            });

            const keys = await this.storage.getActiveApiKeys();
            if (keys.length === 0) break;
            
            const keyToUse = keys[0];
            try {
              const response = await fetch(keyToUse.baseUrl || 'https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${keyToUse.key}` },
                body: JSON.stringify({
                  model: keyToUse.model || 'gpt-4o',
                  messages: [
                    { role: 'system', content: 'You are a browser automation expert. Based on the task, visible elements, and current URL, decide the next action. Actions: click, type, submit, wait, question, or finish. If you need information from the user (like password, email, or details), use "question". Return ONLY JSON: {"action": "click"|"type"|"submit"|"wait"|"question"|"finish", "index": number, "value": "text_to_type", "question": "your_question_here", "reason": "..."}' },
                    { role: 'user', content: `Task: ${prompt}\nURL: ${page.url()}\nLast Action: ${lastAction}\nElements: ${JSON.stringify(interactiveElements.slice(0, 50))}` }
                  ]
                })
              });
              const data = await response.json();
              const content = data.choices[0].message.content;
              const jsonMatch = content.match(/\{[\s\S]*\}/);
              const decision = JSON.parse(jsonMatch ? jsonMatch[0] : content);
              
              lastAction = decision.reason;
              await this.storage.addTaskLog({ taskId, type: "info", content: `AI Action: ${decision.reason}` });

              if (decision.action === 'finish') break;
              if (decision.action === 'question' && decision.question) {
                await this.storage.updateTaskStatus(taskId, "paused", undefined, decision.question);
                return;
              }
              if (decision.action === 'wait') {
                await new Promise(resolve => setTimeout(resolve, 5000));
                continue;
              }

              const targetElement = interactiveElements.find(el => el.index === decision.index);
              
              if (decision.action === 'click' && targetElement) {
                const selector = targetElement.id ? `#${targetElement.id}` : `${targetElement.tagName.toLowerCase()}:nth-child(${decision.index})`;
                // Attempt to click by coordinate if selector is complex
                await page.click(selector).catch(async () => {
                   await page.evaluate((idx) => {
                     const els = document.querySelectorAll('a, button, input, select, textarea, [role="button"], [onclick]');
                     (els[idx] as HTMLElement).click();
                   }, decision.index);
                });
                await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 5000 }).catch(() => {});
              } else if (decision.action === 'type' && targetElement) {
                const selector = targetElement.id ? `#${targetElement.id}` : `${targetElement.tagName.toLowerCase()}`;
                await page.focus(selector).catch(() => {});
                await page.keyboard.type(decision.value || '');
              } else if (decision.action === 'submit') {
                await page.keyboard.press('Enter');
                await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 5000 }).catch(() => {});
              }
              
              // Brief wait for page updates
              await new Promise(resolve => setTimeout(resolve, 1500));
            } catch (e) {
              console.error("Action loop error:", e);
              break;
            }
          }
        }
      } else {
        // Direct discussion
        await this.storage.addTaskLog({ taskId, type: "info", content: `BT4 AI is processing your message...` });
        // Mocking AI response for discussion
        const response = `Hi! I'm BT4 AI, your browser automation assistant. I noticed you just said "${prompt}". If you have a specific web task like "search for latest tech news" or "go to replit.com", just let me know! How can I help you today?`;
        await this.storage.updateTaskStatus(taskId, "completed", response);
        return;
      }

      // Take a screenshot
      const screenshot = await page.screenshot({ encoding: "base64" });
      await this.storage.addTaskLog({
        taskId,
        type: "screenshot",
        content: `data:image/png;base64,${screenshot}`,
        metadata: { url: page.url() }
      });

      // Simulating "AI" thinking
      await this.storage.addTaskLog({ taskId, type: "info", content: "Analyzing page content..." });
      
      const title = await page.title();
      const content = await page.evaluate(() => document.body.innerText.slice(0, 1000));
      
      // Get active API keys and previous tasks for context
      const keys = await this.storage.getActiveApiKeys();
      const previousTasks = await this.storage.getTasks();
      const history = previousTasks
        .filter(t => t.id !== taskId)
        .slice(0, 5)
        .map(t => `User: ${t.prompt}\nAI: ${t.result || 'Processing...'}`)
        .join('\n\n');

      let aiResponse = `Visited ${url} and captured title: ${title}`;

      if (keys.length > 0) {
        const keyToUse = keys[0];
        await this.storage.addTaskLog({ 
          taskId, 
          type: "info", 
          content: `Analyzing with AI (${keyToUse.provider})...`
        });

        try {
          // Actual LLM Call logic
          if (keyToUse.provider === 'openai') {
            const response = await fetch(keyToUse.baseUrl || 'https://api.openai.com/v1/chat/completions', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${keyToUse.key}`
              },
              body: JSON.stringify({
                model: keyToUse.model || 'gpt-4o',
                messages: [
                  { role: 'system', content: 'You are a browser automation assistant. Use the conversation history to provide context-aware responses. Summarize the page content and answer the user prompt.' },
                  { role: 'user', content: `Context History:\n${history}\n\nCurrent Task: ${prompt}\n\nPage Title: ${title}\n\nPage Content: ${content}` }
                ]
              })
            });
            const data = await response.json();
            if (data.choices?.[0]?.message?.content) {
              aiResponse = data.choices[0].message.content;
            }
          }
          await this.storage.rotateKeyUsage(keyToUse.id);
        } catch (llmError: any) {
          await this.storage.addTaskLog({ taskId, type: "warning", content: `AI analysis failed: ${llmError.message}` });
        }
      } else {
         await this.storage.addTaskLog({ 
          taskId, 
          type: "warning", 
          content: "No active API keys found. Using basic summary."
        });
      }

      await this.storage.updateTaskStatus(taskId, "completed", aiResponse);
      await this.storage.addTaskLog({ taskId, type: "info", content: "Task completed successfully." });

    } catch (error: any) {
      console.error("Task failed:", error);
      await this.storage.addTaskLog({
        taskId,
        type: "error",
        content: `Task failed: ${error.message}`
      });
      await this.storage.updateTaskStatus(taskId, "failed", error.message);
    } finally {
      if (browser) {
        await browser.close();
      }
    }
  }
}
