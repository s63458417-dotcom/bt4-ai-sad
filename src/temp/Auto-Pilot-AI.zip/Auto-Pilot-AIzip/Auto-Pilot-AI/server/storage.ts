
import { db } from "./db";
import {
  apiKeys, tasks, taskLogs,
  type InsertApiKey, type InsertTask, type InsertTaskLog,
  type ApiKey, type Task, type TaskLog
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // API Keys
  getApiKeys(): Promise<ApiKey[]>;
  getActiveApiKeys(provider?: string): Promise<ApiKey[]>;
  createApiKey(key: InsertApiKey): Promise<ApiKey>;
  deleteApiKey(id: number): Promise<void>;
  updateApiKey(id: number, updates: Partial<ApiKey>): Promise<ApiKey>;
  rotateKeyUsage(id: number): Promise<void>;

  // Tasks
  getTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTaskStatus(id: number, status: string, result?: string, question?: string): Promise<Task>;

  // Logs
  getTaskLogs(taskId: number): Promise<TaskLog[]>;
  addTaskLog(log: InsertTaskLog): Promise<TaskLog>;

  // Interaction
  answerQuestion(taskId: number, answer: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // API Keys
  async getApiKeys(): Promise<ApiKey[]> {
    return await db.select().from(apiKeys).orderBy(desc(apiKeys.createdAt));
  }

  async getActiveApiKeys(provider?: string): Promise<ApiKey[]> {
    let query = db.select().from(apiKeys).where(eq(apiKeys.isActive, true));
    if (provider) {
      // Logic could be extended to filter by provider if needed
    }
    return await query.orderBy(desc(apiKeys.lastUsedAt)); // Simple rotation strategy: use least recently used? No, actually we might want random or round robin.
    // For now, let's just return all active ones and let the service handle rotation logic.
  }

  async createApiKey(key: InsertApiKey): Promise<ApiKey> {
    const [newKey] = await db.insert(apiKeys).values(key).returning();
    return newKey;
  }

  async deleteApiKey(id: number): Promise<void> {
    await db.delete(apiKeys).where(eq(apiKeys.id, id));
  }

  async updateApiKey(id: number, updates: Partial<ApiKey>): Promise<ApiKey> {
    const [updated] = await db.update(apiKeys).set(updates).where(eq(apiKeys.id, id)).returning();
    return updated;
  }

  async rotateKeyUsage(id: number): Promise<void> {
    await db.update(apiKeys).set({ lastUsedAt: new Date() }).where(eq(apiKeys.id, id));
  }

  // Tasks
  async getTasks(): Promise<Task[]> {
    return await db.select().from(tasks).orderBy(desc(tasks.createdAt));
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async updateTaskStatus(id: number, status: string, result?: string, question?: string): Promise<Task> {
    const [updated] = await db.update(tasks)
      .set({ 
        status, 
        result, 
        question: question || null,
        updatedAt: new Date() 
      })
      .where(eq(tasks.id, id))
      .returning();
    return updated;
  }

  // Logs
  async getTaskLogs(taskId: number): Promise<TaskLog[]> {
    return await db.select().from(taskLogs)
      .where(eq(taskLogs.taskId, taskId))
      .orderBy(taskLogs.createdAt);
  }

  async addTaskLog(log: InsertTaskLog): Promise<TaskLog> {
    const [newLog] = await db.insert(taskLogs).values(log).returning();
    return newLog;
  }

  async answerQuestion(taskId: number, answer: string): Promise<void> {
    await db.transaction(async (tx) => {
      // 1. Add log entry for the user's answer
      await tx.insert(taskLogs).values({
        taskId,
        type: "info",
        content: `User Answer: ${answer}`,
      });

      // 2. Clear the question and set status back to running
      await tx.update(tasks)
        .set({ 
          status: "running", 
          question: null,
          updatedAt: new Date() 
        })
        .where(eq(tasks.id, taskId));
    });
  }
}

export const storage = new DatabaseStorage();
