
import { pgTable, text, serial, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const apiKeys = pgTable("api_keys", {
  id: serial("id").primaryKey(),
  provider: text("provider").notNull(), // 'bt4', 'huggingface', 'openai'
  key: text("key").notNull(),
  baseUrl: text("base_url"), 
  model: text("model"), 
  label: text("label"),
  isActive: boolean("is_active").default(true),
  lastUsedAt: timestamp("last_used_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  prompt: text("prompt").notNull(),
  status: text("status").notNull().default("pending"), // 'pending', 'running', 'paused', 'completed', 'failed'
  result: text("result"),
  question: text("question"), // New field for AI to ask questions
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const taskLogs = pgTable("task_logs", {
  id: serial("id").primaryKey(),
  taskId: serial("task_id").references(() => tasks.id),
  type: text("type").notNull(), // 'info', 'error', 'screenshot', 'action', 'thought'
  content: text("content").notNull(),
  metadata: jsonb("metadata"), 
  createdAt: timestamp("created_at").defaultNow(),
});

// Base types
export type ApiKey = typeof apiKeys.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type TaskLog = typeof taskLogs.$inferSelect;

export type InsertApiKey = typeof insertApiKeySchema._type;
export type InsertTask = typeof insertTaskSchema._type;
export type InsertTaskLog = typeof insertTaskLogSchema._type;

// Schemas
export const insertApiKeySchema = createInsertSchema(apiKeys).omit({ 
  id: true, 
  lastUsedAt: true, 
  createdAt: true 
});

export const insertTaskSchema = createInsertSchema(tasks).omit({ 
  id: true, 
  status: true, 
  result: true, 
  createdAt: true, 
  updatedAt: true 
});

export const insertTaskLogSchema = createInsertSchema(taskLogs).omit({ 
  id: true, 
  createdAt: true 
});

// Explicit Request/Response types for BT4
export type CreateTaskRequest = z.infer<typeof insertTaskSchema>;
export type TaskResponse = Task;
export type LogResponse = TaskLog;
