# BT4 AI - Browser Automation Agent

## Overview

BT4 AI is a browser automation agent application that allows users to submit natural language prompts and have an AI-driven agent perform web browsing tasks. The system uses Puppeteer for browser automation, stores task history and logs in PostgreSQL, and provides a modern chat-style interface for interaction. Users can manage multiple API keys for different AI providers and view real-time task execution logs with screenshots.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight router)
- **State Management**: TanStack React Query for server state with automatic polling for task status updates
- **Styling**: Tailwind CSS with CSS variables for theming, following a dark theme design system
- **UI Components**: shadcn/ui component library (New York style) built on Radix UI primitives
- **Build Tool**: Vite with HMR support

The frontend follows a page-based structure with shared components:
- `client/src/pages/` - Main views (Dashboard, TaskDetails, Settings)
- `client/src/components/` - Reusable components including a custom Sidebar
- `client/src/hooks/` - Custom hooks for API keys, tasks, and mobile detection
- `client/src/components/ui/` - shadcn/ui component library

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful endpoints defined in `shared/routes.ts` with Zod validation
- **Browser Automation**: Puppeteer for headless browser control
- **Build**: esbuild for server bundling, Vite for client

The server architecture includes:
- `server/index.ts` - Express app setup with logging middleware
- `server/routes.ts` - API route handlers for keys, tasks, and logs
- `server/storage.ts` - Database access layer implementing IStorage interface
- `server/services/agent.ts` - AgentService class handling browser automation tasks

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts`
- **Migrations**: Managed via `drizzle-kit push`

Database tables:
- `api_keys` - Stores provider API keys (bt4, huggingface, openai) with activation status
- `tasks` - Tracks automation tasks with prompt, status, and result
- `task_logs` - Stores execution logs including screenshots, actions, and errors

### Shared Code Pattern
The `shared/` directory contains code used by both frontend and backend:
- `schema.ts` - Drizzle table definitions and Zod schemas
- `routes.ts` - API route definitions with input/output schemas for type-safe API calls

### Design System
The application follows detailed design guidelines in `design_guidelines.md`:
- Typography: Inter for UI, JetBrains Mono for code
- Layout: 260px fixed sidebar, centered chat area (max 800px)
- Dark theme with custom color tokens via CSS variables

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connection via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database queries and schema management
- **connect-pg-simple**: Session storage (available but may not be actively used)

### AI/LLM Providers
The system supports multiple API key providers stored in the database:
- BT4 (custom)
- HuggingFace
- OpenAI

API keys include optional `baseUrl` and `model` fields for flexible configuration.

### Browser Automation
- **Puppeteer**: Headless Chrome automation for web browsing tasks
- Configured with `--no-sandbox` and `--disable-setuid-sandbox` for containerized environments

### UI Dependencies
- **Radix UI**: Comprehensive primitive components (dialog, dropdown, toast, etc.)
- **Lucide React**: Icon library
- **date-fns**: Date formatting utilities
- **class-variance-authority**: Component variant management
- **embla-carousel-react**: Carousel functionality
- **react-day-picker**: Calendar component
- **vaul**: Drawer component
- **cmdk**: Command palette

### Development Tools
- **Vite**: Frontend build and dev server with HMR
- **esbuild**: Server bundling for production
- **TypeScript**: Full type safety across the stack